package ro.ase.acs.contracts;

public interface Readable {
    public String read();
}
