package ro.ase.acs.contracts;

public interface Writeable {
    public void print(String message);
}
